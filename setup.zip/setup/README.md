

Con la ayuda de dos herramientas:


DefenderControl_v1.5  : https://yadi.sk/d/QLD4fyKk0bzKOA

NSudo : https://github.com/M2Team/NSudo/releases/tag/8.0

Se logro Deshabilitar y Habilitar el Windows Defender, con el siguiente Script PS puedes detener el Widnows Defender ejecutar todos las lineas
De comando que necesitas y luego habilitarlo sin problemas.
